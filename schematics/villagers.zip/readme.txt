Thanks for downloading the SVM Clone Pack for Minecraft!

Instructions on placeing the clones in your world are here:
http://youtu.be/uzG-BffKYyU

To apply the textures, copy the 'villager' folder into the
'mob' folder instead your SVM Texture Pack or any other
32 x 32 pack.

Thanks for downloading!
SVM
youtube/shawnvmartin
twitter/shawnvmartin

Clones were made by Ron Smalec
youtube/rsmalec
twitter/rsmalec